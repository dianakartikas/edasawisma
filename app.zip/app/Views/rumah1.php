<!DOCTYPE html>
<html lang="en">


<?= $this->extend('index'); ?>
<?= $this->section('dashboard'); ?>
<style>
    thead,
    tfoot {
        background-color: #3f87a6;
        color: #fff;
    }

    tbody {
        background-color: #f2f9fc;
        color: #000;
    }

    caption {
        padding: 10px;
        caption-side: bottom;
    }

    table {
        border-collapse: collapse;
        border: 2px solid rgb(200, 200, 200);
        letter-spacing: 1px;
        font-family: sans-serif;
        font-size: .8rem;
    }

    td,
    th {
        border: 1px solid rgb(190, 190, 190);
        padding: 5px 10px;
    }

    td {
        vertical-align: center;

    }
</style>
<!-- Topbar -->

<!-- End of Topbar -->

<!-- Begin Page Content -->
<div class="container-fluid">
    <h1 class="h3 mb-2 text-gray-800">Rumah</h1>
    <p class="mb-4">Data berisikan kriteria rumah sehat layak huni dengan kategori tempat pembuangan sampah, SPAL, dan jamban keluarga.
        <br><small><a target="_blank" href="https://batangtoru.tapselkab.go.id/">Kecamatan Batangtoru Kabupaten Tapanuli Selatan.</a></small> <br> <a target="_blank" href="https://batangtoru.tapselkab.go.id/">Dokumen Tutorial</a>.
    </p>
    <?php if (session()->getFlashdata('success')) : ?>

        <div class="alert alert-success" role="alert"><?= session()->getFlashdata('success'); ?></div>
    <?php endif; ?>
    <?php if (session()->has('errors')) : ?>
        <ul class="alert alert-danger">
            <?php foreach (session('errors') as $error) : ?>
                <li><?= $error ?></li>
            <?php endforeach ?>
        </ul>
    <?php endif ?></p>
    <!-- DataTales Example -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <button type="button" class="btn-sm btn-primary btn-icon-split" data-toggle="modal" data-target="#formTambahRumah">
                <span class="icon text-white-50">
                    <i class="fas fa-plus"></i>
                </span>
                <span class="text">Kriteria Rumah</span>
            </button>
        </div>

        <div class="card-body">
            <div class="table-responsive">
                <table id="dtHorizontalExample" class="table table-striped table-bordered table-sm" width="100%">
                    <thead>
                        <tr>
                            <th style="text-align: center;">No.</th>
                            <th style="text-align: center;">Gambar</th>
                            <th style="text-align: center;">Nama Kepala Keluarga</th>
                            <th style="text-align: center;">Pembuangan Sampah</th>
                            <th style="text-align: center;">SPAL</th>
                            <th style="text-align: center;">Jamban Keluarga</th>
                            <th style="text-align: center;">Stiker PKK</th>
                            <th style="text-align: center;">Keterangan</th>

                            <th style="text-align: center;">Edit</th>
                            <th style="text-align: center;">Hapus</th>

                        </tr>
                    </thead>
                    <?php if (in_groups('superadmin')) : ?>
                        <tbody>
                            <?php
                            $nomor = 1;
                            foreach ($rumah as $row) :
                            ?>
                                <tr>
                                    <td style="vertical-align: middle;text-align: center;"><?= $nomor++; ?></td>
                                    <td><img src="<?= base_url('/img/rumah/' . $row['gambar_rumah']); ?>" class="card-img-top card-img-fluid" alt="gambar_rumah<?= $row['nama']; ?>" width="10px" /></td>
                                    <td style="vertical-align: middle;text-align: center;"><?= $row['nama']; ?></td>
                                    <?php if ($row['pembuangan_sampah'] == "Iya") {
                                    ?>
                                        <td style="vertical-align: middle;text-align: center;"><span class="badge badge-success"><i class="fas fa-fw fa-check"></i></span></td>

                                    <?php } else if ($row['pembuangan_sampah'] == "Tidak") { ?>
                                        <td style="vertical-align: middle;text-align: center;"><span class="badge badge-danger">X</i></span>
                                        </td>


                                    <?php  } else { ?>
                                        <td></td>


                                    <?php } ?>
                                    <td style="vertical-align: middle;text-align: center;"><?= $row['spal']; ?></td>
                                    <td style="vertical-align: middle;text-align: center;"><?= $row['jamban_keluarga']; ?></td>
                                    <td style="vertical-align: middle;text-align: center;"><?= $row['stiker_pkk']; ?></td>
                                    <?php if ($row['keterangan'] == "Sehat") {
                                    ?>
                                        <td style="vertical-align: middle;text-align: center;"><span class="badge badge-success"><?= $row['keterangan']; ?></span></td>

                                    <?php } else if ($row['keterangan'] == "Tidak Sehat") { ?>
                                        <td style="vertical-align: middle;text-align: center;"><span class="badge badge-danger"><?= $row['keterangan']; ?></span>
                                        </td>


                                    <?php  } else { ?>
                                        <td></td>
                                    <?php } ?>
                                    <td>
                                        <button type="button" class="btn btn-primary btn-sm btn-block" data-toggle="modal" data-target="#modaledit<?= $row['id_rumah']; ?>">
                                            <span class="icon text-white-50">
                                                <i class="fa fa-edit"></i>
                                            </span>
                                            <span class="text">Edit</span>
                                        </button>
                                    </td>
                                    <td>
                                        <button type="button" class="btn btn-danger btn-sm btn-block" onclick="hapus('<?= $row['id_rumah'] ?>','<?= $row['nama'] ?>')">
                                            <span class="icon text-white-50">
                                                <i class="fa fa-trash"></i>
                                            </span>
                                            <span class="text">Hapus</span>
                                        </button>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    <?php endif; ?>
                    <?php if (in_groups('admin')) : ?>
                        <tbody>
                            <?php
                            $nomor = 1;
                            foreach ($rumahAdmin as $row) :
                            ?>
                                <tr>
                                    <td style="vertical-align: middle;text-align: center;"><?= $nomor++; ?></td>
                                    <td><img src="<?= base_url('/img/rumah/' . $row['gambar_rumah']); ?>" class="card-img-top card-img-fluid" alt="gambar_rumah<?= $row['nama']; ?>" width="10px" /></td>
                                    <td style="vertical-align: middle;text-align: center;"><?= $row['nama']; ?></td>
                                    <?php if ($row['pembuangan_sampah'] == "Iya") {
                                    ?>
                                        <td style="vertical-align: middle;text-align: center;"><span class="badge badge-success"><i class="fa-light fa-circle-check"></i></span></td>

                                    <?php } else if ($row['pembuangan_sampah'] == "Tidak") { ?>
                                        <td style="vertical-align: middle;text-align: center;"><span class="badge badge-danger"><i class="fa-regular fa-circle-xmark"></i></span>
                                        </td>


                                    <?php  } else { ?>
                                        <td></td>


                                    <?php } ?>
                                    <td style="vertical-align: middle;text-align: center;"><?= $row['pembuangan_sampah']; ?></td>
                                    <td style="vertical-align: middle;text-align: center;"><?= $row['spal']; ?></td>
                                    <td style="vertical-align: middle;text-align: center;"><?= $row['jamban_keluarga']; ?></td>
                                    <td style="vertical-align: middle;text-align: center;"><?= $row['stiker_pkk']; ?></td>
                                    <?php if ($row['keterangan'] == "Sehat") {
                                    ?>
                                        <td style="vertical-align: middle;text-align: center;"><span class="badge badge-success"><?= $row['keterangan']; ?></span></td>

                                    <?php } else if ($row['keterangan'] == "Tidak Sehat") { ?>
                                        <td style="vertical-align: middle;text-align: center;"><span class="badge badge-danger"><?= $row['keterangan']; ?></span>
                                        </td>


                                    <?php  } else { ?>
                                        <td></td>


                                    <?php } ?>
                                    <td>
                                        <button type="button" class="btn btn-primary btn-sm btn-block" data-toggle="modal" data-target="#modaledit<?= $row['id_rumah']; ?>">
                                            <span class="icon text-white-50">
                                                <i class="fa fa-edit"></i>
                                            </span>
                                            <span class="text">Edit</span>
                                        </button>
                                    </td>
                                    <td>
                                        <button type="button" class="btn btn-danger btn-sm btn-block" onclick="hapus('<?= $row['id_rumah'] ?>','<?= $row['nama'] ?>')">
                                            <span class="icon text-white-50">
                                                <i class="fa fa-trash"></i>
                                            </span>
                                            <span class="text">Hapus</span>
                                        </button>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    <?php endif; ?>
                </table>
            </div>

        </div>

    </div>
</div>


<div class="modal fade" id="formTambahRumah" data-backdrop="static" tabindex="-1" aria-labelledby="exampleModalLabel" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Tambah Kriteria Rumah</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <form action="rumah/save" method="post" enctype="multipart/form-data">
                <div class="modal-body">
                    <?= csrf_field(); ?>
                    <div class="form-group row">
                        <label for="inputPassword3" class="col-sm-4 col-form-label">Kepala Keluarga</label>
                        <div class="col-sm-8">
                            <select name="id_kk" id="id_kk" class="form-control<?= ($validation->hasError('id_kk')) ? ' is-invalid' : '' ?>">
                                <?php if (in_groups('superadmin')) : ?>
                                    <option value="">-- Pilih Kepala Keluarga --</option>
                                    <?php
                                    foreach ($kepalaKeluarga as $row) :
                                    ?>
                                        <option value="<?= $row['id_kk']; ?>"><?= $row['nama']; ?></option>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                                <?php if (in_groups('admin')) : ?>
                                    <option value="">-- Pilih Kepala Keluarga --</option>
                                    <?php
                                    foreach ($kepalaKeluargaAdmin as $row) :
                                    ?>
                                        <option value="<?= $row['id_kk']; ?>"><?= $row['nama']; ?></option>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </select>
                        </div>
                    </div>
                    <fieldset class="form-group">
                        <div class="row">
                            <legend class="col-form-label col-sm-9 pt-0">Apakah Tersedia Pembuangan Sampah?</legend>
                            <div class="col-sm-3">
                                <div class="form-check">
                                    <input class="form-check-input" type="radio" name="pembuangan_sampah" id="pembuangan_sampah" value="Iya" checked>
                                    <label class="form-check-label" for="Iya">
                                        Iya
                                    </label>
                                </div>
                                <div class="form-check">
                                    <input class="form-check-input" type="radio" name="pembuangan_sampah" id="pembuangan_sampah" value="Tidak">
                                    <label class="form-check-label" for="Tidak">
                                        Tidak
                                    </label>
                                </div>
                            </div>
                        </div>
                    </fieldset>
                    <fieldset class="form-group">
                        <div class="row">
                            <legend class="col-form-label col-sm-9 pt-0">Apakah Tersedia SPAL?</legend>
                            <div class="col-sm-3">
                                <div class="form-check">
                                    <input class="form-check-input" type="radio" name="spal" id="spal" value="Iya" checked>
                                    <label class="form-check-label" for="Iya">
                                        Iya
                                    </label>
                                </div>
                                <div class="form-check">
                                    <input class="form-check-input" type="radio" name="spal" id="spal" value="Tidak">
                                    <label class="form-check-label" for="Tidak">
                                        Tidak
                                    </label>
                                </div>
                            </div>
                        </div>
                    </fieldset>
                    <fieldset class="form-group">
                        <div class="row">
                            <legend class="col-form-label col-sm-9 pt-0">Apakah Tersedia Jamban Keluarga?</legend>
                            <div class="col-sm-3">
                                <div class="form-check">
                                    <input class="form-check-input" type="radio" name="jamban_keluarga" id="jamban_keluarga" value="Iya" checked>
                                    <label class="form-check-label" for="Iya">
                                        Iya
                                    </label>
                                </div>
                                <div class="form-check">
                                    <input class="form-check-input" type="radio" name="jamban_keluarga" id="jamban_keluarga" value="Tidak">
                                    <label class="form-check-label" for="Tidak">
                                        Tidak
                                    </label>
                                </div>
                            </div>
                        </div>
                    </fieldset>
                    <fieldset class="form-group">
                        <div class="row">
                            <legend class="col-form-label col-sm-9 pt-0">Apakah menempel stiker PKK?</legend>
                            <div class="col-sm-3">
                                <div class="form-check">
                                    <input class="form-check-input" type="radio" name="stiker_pkk" id="stiker_pkk" value="Iya" checked>
                                    <label class="form-check-label" for="Iya">
                                        Iya
                                    </label>
                                </div>
                                <div class="form-check">
                                    <input class="form-check-input" type="radio" name="stiker_pkk" id="stiker_pkk" value="Tidak">
                                    <label class="form-check-label" for="Tidak">
                                        Tidak
                                    </label>
                                </div>
                            </div>
                        </div>
                    </fieldset>

                    <div class="form-group row">
                        <label for="inputPassword3" class="col-sm-4 col-form-label">Gambar Rumah</label>
                        <div class="col-sm-8">
                            <input type="file" name="gambar_rumah" id="gambar_rumah" class="form-control<?= ($validation->hasError('gambar_rumah')) ? ' is-invalid' : '' ?>">
                            <div class="invalid-feedback">
                                <?= $validation->getError('gambar_rumah'); ?>
                            </div>
                        </div>
                    </div>

                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Kembali</button>
                        <button type="submit" class="btn btn-primary">Simpan</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>

<?php foreach ($rumah as $row) : ?>
    <div class="modal fade" id="modaledit<?= $row['id_rumah']; ?>" tabindex="-1" aria-labelledby="modaleditLabel" role="dialog" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="modaleditLabel">Edit <?= $row['nama']; ?></h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <?= csrf_field(); ?>
                <form action="rumah/update/<?= $row['id_rumah']; ?>" method="post" enctype="multipart/form-data">
                    <div class="modal-body">
                        <div class="form-group row">
                            <input type="hidden" name="gambarLama" value="<?= $row['gambar_rumah']; ?>">

                            <label for="inputEmail3" class="col-sm-3 col-form-label">Nama</label>
                            <div class="col-sm-9">
                                <input type="text" name="nama" id="nama" class="form-control" value="<?= $row['nama']; ?>" readonly>
                                <div class="invalid-feedback">
                                    <?= $validation->getError('nama'); ?>
                                </div>
                            </div>
                        </div>
                        <fieldset class="form-group">
                            <div class="row">
                                <legend class="col-form-label col-sm-3 pt-0">Pembuangan Sampah?</legend>
                                <div class="col-sm-9">
                                    <div class="form-check">
                                        <input class="form-check-input" type="radio" name="pembuangan_sampah" id="pembuangan_sampah" value="Iya" <?php if ($row['pembuangan_sampah'] == 'Iya') { ?> checked="checked" <?php } ?>>
                                        <label class="form-check-label" for="buta">
                                            Iya
                                        </label>
                                    </div>
                                    <div class="form-check">
                                        <input class="form-check-input" type="radio" name="pembuangan_sampah" id="pembuangan_sampah" value="Tidak" <?php if ($row['pembuangan_sampah'] == 'Tidak') { ?> checked="checked" <?php } ?>>
                                        <label class="form-check-label" for="buta">
                                            Tidak
                                        </label>
                                    </div>
                                </div>
                            </div>
                        </fieldset>
                        <fieldset class="form-group">
                            <div class="row">
                                <legend class="col-form-label col-sm-3 pt-0">SPAL?</legend>
                                <div class="col-sm-9">
                                    <div class="form-check">
                                        <input class="form-check-input" type="radio" name="spal" id="spal" value="Iya" <?php if ($row['spal'] == 'Iya') { ?> checked="checked" <?php } ?>>
                                        <label class="form-check-label" for="buta">
                                            Iya
                                        </label>
                                    </div>
                                    <div class="form-check">
                                        <input class="form-check-input" type="radio" name="spal" id="spal" value="Tidak" <?php if ($row['spal'] == 'Tidak') { ?> checked="checked" <?php } ?>>
                                        <label class="form-check-label" for="buta">
                                            Tidak
                                        </label>
                                    </div>
                                </div>
                            </div>
                        </fieldset>
                        <fieldset class="form-group">
                            <div class="row">
                                <legend class="col-form-label col-sm-3 pt-0">Jamban Keluarga?</legend>
                                <div class="col-sm-9">
                                    <div class="form-check">
                                        <input class="form-check-input" type="radio" name="jamban_keluarga" id="jamban_keluarga" value="Iya" <?php if ($row['jamban_keluarga'] == 'Iya') { ?> checked="checked" <?php } ?>>
                                        <label class="form-check-label" for="buta">
                                            Iya
                                        </label>
                                    </div>
                                    <div class="form-check">
                                        <input class="form-check-input" type="radio" name="jamban_keluarga" id="jamban_keluarga" value="Tidak" <?php if ($row['jamban_keluarga'] == 'Tidak') { ?> checked="checked" <?php } ?>>
                                        <label class="form-check-label" for="buta">
                                            Tidak
                                        </label>
                                    </div>
                                </div>
                            </div>
                        </fieldset>
                        <fieldset class="form-group">
                            <div class="row">
                                <legend class="col-form-label col-sm-3 pt-0">Stiker PKK?</legend>
                                <div class="col-sm-9">
                                    <div class="form-check">
                                        <input class="form-check-input" type="radio" name="stiker_pkk" id="stiker_pkk" value="Iya" <?php if ($row['stiker_pkk'] == 'Iya') { ?> checked="checked" <?php } ?>>
                                        <label class="form-check-label" for="buta">
                                            Iya
                                        </label>
                                    </div>
                                    <div class="form-check">
                                        <input class="form-check-input" type="radio" name="stiker_pkk" id="stiker_pkk" value="Tidak" <?php if ($row['stiker_pkk'] == 'Tidak') { ?> checked="checked" <?php } ?>>
                                        <label class="form-check-label" for="buta">
                                            Tidak
                                        </label>
                                    </div>
                                </div>
                            </div>
                        </fieldset>

                        <label for="gambar_rumah">Foto</label>
                        <div class="form-group row">
                            <div class="col-sm-2">
                                <img src="/img/rumah/<?= $row['gambar_rumah']; ?>" class="img-thumbnail img-preview">
                            </div>
                            <div class="col-sm-10">
                                <div class="custom-file">
                                    <input type="file" class="custom-file-input <?= ($validation->hasError('gambar_rumah')) ? 'is-invalid' : ''; ?>" id="gambar_rumah" name="gambar_rumah" onchange="previewImg()">
                                    <div class=" invalid-feedback">
                                        <?= $validation->getError('gambar_rumah'); ?>
                                    </div>
                                    <label class="custom-file-label" for="gambar_rumah2"><?= $row['gambar_rumah']; ?></label>
                                </div>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Kembali</button>
                            <button type="submit" class="btn btn-primary">Perbarui</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>

<?php endforeach; ?>
<!-- Bootstrap core JavaScript-->
<script src="<?= base_url(); ?>/vendor/jquery/jquery.min.js"></script>
<script src="<?= base_url(); ?>/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

<!-- Core plugin JavaScript-->
<script src="<?= base_url(); ?>/vendor/jquery-easing/jquery.easing.min.js"></script>

<!-- Custom scripts for all pages-->
<script src="<?= base_url(); ?>/js/sb-admin-2.min.js"></script>
<script href="https://code.jquery.com/jquery-3.5.1.js"></script>
<script href="https://cdn.datatables.net/1.12.1/js/jquery.dataTables.min.js"></script>


<!-- Page level plugins -->
<script src="<?= base_url(); ?>/vendor/datatables/jquery.dataTables.min.js"></script>
<script src="<?= base_url(); ?>/vendor/datatables/dataTables.bootstrap4.min.js"></script>

<!-- Page level custom scripts -->
<script src="<?= base_url(); ?>/js/demo/datatables-demo.js"></script>
<script>
    $(function() {

        <?php if (session()->getFlashdata("success")) { ?>
            Swal.fire({
                icon: 'success',
                title: 'Berhasil',
                text: '<?= session("success") ?>'
            })
        <?php } ?>
    });

    $(function() {

        <?php if (session()->has("errors")) { ?>
            Swal.fire({
                icon: 'error',
                title: 'Terjadi Kesalahan',
                text: '<?= session("error") ?>'
            })
        <?php } ?>
    });
</script>
<script>
    $(function() {

        <?php if (session()->getFlashdata("warning")) { ?>
            Swal.fire({
                icon: 'warning',
                title: 'Periksa Data!',
                text: '<?= session("warning") ?>'
            })
        <?php } ?>
    });
</script>
<script>
    $(function() {
        <?php if (session()->getFlashData('status')) { ?>
            swall({
                tittle: "<?= session()->getFlashData('status'); ?>",
                text: "<?= session()->getFlashData('status_text'); ?>",
                icon: "<?= session()->getFlashData('status_icon'); ?>",
                button: "OK",

            });
        <?php } ?>
    });
</script>
<script>
    function hapus(id_rumah) {
        Swal.fire({
            title: 'hapus',
            text: `Yakin menghapus kriteria rumah ini ?`,
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Ya, Hapus!',
            cancelButtonText: 'Tidak',
        }).then((result) => {
            if (result.value) {
                $.ajax({
                    type: "post",
                    url: "<?= site_url('rumah/hapus') ?>",
                    data: {
                        id_rumah: id_rumah
                    },
                    dataType: "json",

                    success: function(response) {
                        if (response.sukses) {
                            Swal.fire({
                                    icon: 'success',
                                    title: 'Berhasil',
                                    text: response.sukses,
                                })
                                .then(function() {
                                    window.location.reload();
                                })
                        }
                    },
                    error: function(xhr, ajaxOptios, thrownError) {
                        alert(xhr.status + "\n" + xhr.responseText + "\n" +
                            thrownError);

                    }
                });
            }
        })
    }
</script>

</html>
<script>
    function previewImg() {

        const gambar = document.querySelector('#gambar_rumah');
        const gambarLabel = document.querySelector('.custom-file-label');
        const imgPreview = document.querySelector('.img-preview');

        gambarLabel.textContent = gambar.files[0].name;
        const filegambar = new FileReader();
        filegambar.readAsDataURL(gambar.files[0]);

        filegambar.onload = function(e) {

            imgPreview.src = e.target.result;

        }
    }
</script>
<script>
    $(document).ready(function() {
        $('#dtHorizontalExample').DataTable({
            "scrollX": true
        });
        $('.dataTables_length').addClass('bs-select');
    });
</script>

<?= $this->endSection(); ?>